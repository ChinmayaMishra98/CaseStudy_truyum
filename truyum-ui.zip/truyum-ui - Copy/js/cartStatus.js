function addToCart() {
    document.getElementById("add-status").innerHTML="Item added to Cart Successfully";
}

function deleteFromCart() {
    document.getElementById("delete-status").innerHTML="Item removed from Cart Successfully";
}
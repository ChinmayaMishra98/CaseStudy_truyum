
create database truyum
go
use truyum
go
create table menu_item (
item_id int identity(1,1) primary key,
item_name varchar(50),
price decimal(6,2),
active varchar(5),
date_of_launch date,
category varchar(50),
free_delivery varchar(5),
check(active in ('Yes','No')),
check(category in ('Starter','Main Course','Desserts','Drinks')),
check(free_delivery in ('Yes','No'))
);

create table [user] (
user_id int identity(1,1) primary key,
user_name varchar(100)
);

create table cart (
cart_id int identity(1,1) primary key,
item_id int,
user_id int,
foreign key (item_id) references menu_item(item_id),
foreign key (user_id) references [user](user_id)
);
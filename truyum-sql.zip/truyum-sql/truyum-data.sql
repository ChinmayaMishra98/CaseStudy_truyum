/*inserting data into menu table.(TYUC001-a)*/
insert into menu_item (item_name,price,active,date_of_launch,category,free_delivery)
values('Sandwich',99.00,'Yes','2017-03-15','Main Course','Yes'),
('Burger',129.00,'Yes','2017-12-23','Main Course','No'),
('Pizza',149.00,'Yes','2017-08-21','Main Course','No'),
('French Fries',57.00,'No','2017-07-02','Starter','Yes'),
('Chocolate',32.00,'Yes','2022-11-02','Desserts','Yes')
go

/*getting all menu items.(TYUC001-b)*/
select item_name,concat('Rs. ',price) as price,active,date_of_launch,category,free_delivery from menu_item
go

/*getting all menu items which are before launch date and is active.(TYUC002)*/
select item_name,free_delivery,concat('Rs. ',price) as price,category from menu_item
where date_of_launch<getdate()
and active='Yes'
go

/*getting a menu item based on Menu Item Id from menu table.(TYUC003-a)*/
create proc GetMenuItemFromId(@item_id int) as
begin
	select item_name,concat('Rs. ',price) as price,active,date_of_launch,category,free_delivery from menu_item
	where item_id=@item_id
end
go

/*updating all column values based on menu item id in menu table.(TYUC003-b)*/
create proc UpdateOnItemId(@item_id int, @item_name varchar(50), @price decimal(6,2), @active varchar(5), @date_of_launch date,
							@category varchar(50), @free_delivery varchar(5)) as
begin
	update menu_item
	set item_name=@item_name,
	price=@price,
	active=@active,
	date_of_launch=@date_of_launch,
	category=@category,
	free_delivery=@free_delivery
	where item_id=@item_id
end
go

/*inserting username(TYUC004)*/
create proc InsertUserName(@user_name varchar(100)) as
begin
	insert into [user] (user_name) 
	values(@user_name)
end
go

/*inserting items into cart with no items(TYUC004)*/
insert into cart (item_id,user_id)
values(null,1)
go

/*inserting items into cart with atleast 3 items(TYUC004)*/
insert into cart (item_id,user_id)
values(1,2),(2,2),(3,2)
go

/*getting all menu items in a particular user’s cart(TYUC005-a)*/
create proc GetMenuItemsFromUserId(@user_id int) as
begin
	select m.item_name,m.free_delivery,concat('Rs. ',m.price) as price from menu_item m 
	join cart c on m.item_id=c.item_id
	join [user] u on c.user_id=u.user_id
	where c.user_id=@user_id
end
go

/* getting the total price of all menu items in a particular user’s cart(TYUC005-b)*/
create proc GetTotalPriceOfUser(@user_id int) as
begin
	select concat('Rs. ',cast(sum(m.price) as char)) as total from menu_item m 
	join cart c on m.item_id=c.item_id
	join [user] u on c.user_id=u.user_id
	where c.user_id=@user_id
end
go

/* removing a menu items from Cart based on User Id and Menu Item Id*/
create proc DeleteFromCart(@user_id int, @item_id int) as
begin
	delete from cart 
	where user_id=@user_id
	and item_id=@item_id;
end
go